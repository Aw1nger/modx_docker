<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '3973dddf85a40cbcb861ffcb370fddb9',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/6a6ae15d726144ee82ae4a52919e2b7c.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => 'b039ab40b3234bfd1f37369bb9a33212',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/a46b4854fd73f8049789e1fc31666cde.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => 'ea000a9c72fca2a1bf65797c23491b5f',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/b2ef895d23d716bc6c9edfec05b35707.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '15f46487d6f3a592791389ad6a7f6716',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/a9c006a7ef287ff9620fa53df6b33520.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '79d5ab980e9923e62f9817426be6cf00',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/8f7cd362b69011c600d1e62d436a6421.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'b4709e6aa36b22b8896e501df6f298bc',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/43608587533ed5828613b75b5dfa5860.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '7ef1b5efb8af0369e5330d60d6e6077d',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/a4704692a9accbc6bc27ffb5793f1694.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'ba3a3f630a3a7073651e676e8c764277',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/7eadc0e222a6b4d416e1aef91c14563f.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '01e3ffd257e58efe102f6b9ebdc5788f',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/c3cd5d84256589d5dcf36fd696ec9894.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '92fc73c06b2d94036a346c33febe16ef',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/c82c53d3239e339735d8b02ec1876adb.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'e0010da0a8a6800cdc8c45259e8ec10b',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/0b25efc8d3c6e0d8ca04da2f37baf813.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'edd630f71c305cdb7f3f559f050dc898',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/6f25dc61b1ae72161f62db519a037f14.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '0cf49f5cb4644e1dd591f847d076afa3',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/93d0e7f7dd7ded883a9d6e809b4ea8e9.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b3b55c8bd63a59d1968a81504288502f',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/a26595b44493b1d6a0a964cf11a2b472.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e73c6a6953eb52d019b9897042fbd00e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/a051ccf3c2577d9e0dd5be402a48a4cf.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0b1be85a9bbb926146dd89f4892f519d',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0e1c3770e9ac1f7cabe6a6b38b423f23.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '65008c8174bf6e83575c4afc301feeed',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/e1c9ff8ba4658c3db3e513a67daf3f08.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '58cd53e774bf792231cf48128774e4f3',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/e48f6ddf08a8226ada3f0d547ad4711a.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '92e19aae57a3ec36a926421814e6ea3e',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/5d6df4f3001fa9d40971d92a6444190f.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ebd30a3d2daae75b745c9f2b576ace2d',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/1650f74932f0d75d213adf3105814c59.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'af5dcf2d3d0ef1e07aa63936d4de1ba1',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/2e55233b252490964cc284e2492616dd.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5ebde1959b376c41142ee3ad879c8150',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/1b2bb0f12e076ec1cd42f1710d34d8e3.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd23073f9b1ff6684c9afbc937793f09d',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/a44cd17543c64cacb3dd7578afc37591.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f891aa6ecca46688eb797cf42e469da',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/31c892d90869aff67e4c25b045ebd12b.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '198cd5c9e4ea03d80e5060af00147f66',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/9cf041dd26e3e6d9517b33fdbd529c1d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c8f7edbd8ae5d499ffc1db499bdbe265',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/7c3ef0bbedd433b274e3ad6c57d351c7.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1e7e96724b517a7ad263e393db75102e',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/a68be20eaf57c15204f6d66be1526a98.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4f3e84b1cb0269ec5da6e5345639d5b3',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/ef633beaba5a0b9e2bba7a6c6a62f548.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fe739d2447fa088f6f77df4e69302d18',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/8fe09648d81bdbcb3a9912c9f87d6af1.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '190170b5605792bdd62aea9a88d094a6',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6d20ec73982de4444744b2b993189129.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3003d4b14dcca6d93c8be1288ad39742',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f4af06ca0983f294a03a6f4cc40e0237.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a56fad7fa7c8e81ac1a221a86a0cf413',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c9e11b61ece962c17ee929913bf920f3.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6e9598ab0d7c69df9001d89455876f70',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/a2eff06e3b2c775f1b3b982d68d50664.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '339ff7cdb677867ac7f64ad60039293b',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/0b2f090f52c5da26276b98cacd9c3aa6.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '58532707795d770d4ab9d0534c453600',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/440f9c21b8462ce0fa8417b052a05dcc.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e983b091c7a42c5e6c66c6333aee6e1',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/c573ba9e18b270b19f1c19f8dd6b89fd.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e2d3c7d8fefaf13fd5d13b00f5e9036e',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/a29d4e89e481d6a74908d1ccde0f229d.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd32e59b5eed17f57946a5e722181f832',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/70d62b18356469a3833baac36263c146.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3735bd8786d6cf718a07fcf23072d1ba',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/6c2cbbe7d37f4cb038db9d1c2b12638e.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b2e058a7ffad29d6e2310df5884353ab',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/30c9201c085cc304e077cd3a25679b8c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1be5eedfb832fc6cfab5c1f880efa480',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/3afb898a7ef3adffb03cbbbcc38208b3.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7e5f98d2ebd1c563e6e475265fed552e',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e8d102fb7efe889f7c3f63c76f098f90.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '69cf33cfed25e4d3e60c03b62f516d16',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/82f2ea6fa92f92111c2e76b0c8c6f09c.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a1bd90a981d6397a86b9dc757d762385',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/bd43ce1414342b7b0c3d2c9e53c19e67.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8b3b6f74a4d5e3a25197e54f9135d29c',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/4af8e1c4971d067bf39a8cecf7ea26e4.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bebcafec6e59841bdc61245cf274b31e',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/c23a497435d73e2def00d03333e2a448.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd05c98b8ac537fc35dfeee4853c8fd55',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/f126da6464be01afb53aff54b1ef6221.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2636a4420c9e780fd4efbfc5ae081a34',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/1b95a1854b0129f9f0bad4fa28426bc6.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '808c43adfadd997571cd6024bc4c91c8',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/ac8da4a51d27def821bbd4609feacd63.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f344e426b6beaec9bf0930381218345',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e894f567a223831068e08cf5562fea01.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '659450cc3759f814aa0e6d80e528661e',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/3eff974d920e4a5a6543eb83b83fdcd1.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '22ce83edda0f02b393c4c2982758a030',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/d135b5ba347e94f73cd3855f9c930f52.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '705da0b0f3253eab59ac3704a3afd07d',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/72711214bfb4617c8c06586741bbce17.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '96886571f4005535d32d139708c47c56',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/b736142bff67ef4e545f23a3773e119e.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1485d132c075db88ceada86ae8b5c231',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/4c8c75bdbcb7fc12a28606dd54d4146d.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eb5d59b99581aacb0acc4f04121bfa57',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/5cb47df0caa93b6929c6cf28bef691cb.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6b3219ecb0f26ab434aa4012992dcb39',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/35b75e202c02888c3bfd0a5815e0cb32.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11e22324b93d45d343d11a2b254153ef',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/88b8f725f5e918fc5e46b3aa70a9065f.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7a51c3c23e275d6e021cd609b8ebeb78',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/ab88964e31f34d9bc2eeac4c3ccd0252.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'caa33c0cb0bf39dd09fb6ae380927edd',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/d2ca36b2fc14362f6f4b7fba4c2ca02a.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01cbe9db5897b34fa1bd32bf15b986af',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/808c44962452f23b5da9c5cd1ae623d8.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6473b4897a75d2f0291899bc8ae4e9ac',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/7a7a8682604a2565510001ad3feb43a5.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '339e8c6505512b2e2a949bb95d9bffbc',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/20441036821ff6f75b746d65682334c9.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e8f74d1c862588dedebaff379c7947f5',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c71bff612dd37dc1c8bda7e24d3ece6f.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '62e1d608e4208c9a402de030347a735a',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/bc08aadd19023a597ae689c014767db3.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '257a8c4d7cba080c9d3b24346f265557',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/05905854e0b679e0a855d1b771dd4409.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c027ff0bc3440d5c81937c972064a651',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/b9d074a9fa5a5bbe1b8ed6bf701c6b9a.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f2d184e628cddbbafe141406328b2e3d',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/fe10dac96655a23b6916a6f6ef47b8f4.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '093db8ae2a2e5446c529de68e7ee3b56',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/0b23f97e07e56146ee7e3c4df0d0fa56.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '52e32d1a5fc493157214947fdeb8b59e',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/4d76d994953441c251f0d24c8fe997c5.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '234731f4d6d67b739f0558b95eba35f9',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/a04935661769561e36d2af1f9e595004.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c1564664fe96a26b41a7e1496a7f343a',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/2821bcfec62ecc7c61c15156680dedfb.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2edc8d318c739d06ee36f3a6ca4d75e3',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/84bb81d646e1032ac0fa432b2798b9b6.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e3eac2d8e7fcc64236a58acb4c76906d',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/465b338b639f50ddfd6528b5cd52975b.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2ab77a4cc33d3ab7deb17513ecd3d8fb',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/23bf5aa9676e77cf69b2483e7dd06c8a.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cfaefc4a62151a439eefce8b2bd73a54',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/c34670f88645a7c6e936201dfe4730e6.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '96958df8bfbdc4bf70ec88c95a5a8cf8',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/459d70bb7660b0ff106b0899fcd62166.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ca06465b650a11d6975927919c778f94',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6713dec3a76c1daa9d1bee03f63b39e2.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd5a334a05d98ab689a93b308b4fa01df',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/0ccbf3ab295365b804830f30e15953f9.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b787c129fae183a9f1c338bcba607eb3',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/0ca55a66e1e48e07d0896b3eece33ef9.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f974bebea1147ce9395e8bcd416122f9',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/a4ac15ba5a1e9af494d2c849e85b3381.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e7966cc68e2b04fdb214478d963f6fcc',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/0b147f375cad464c834704a81ec37c58.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b83310ba8826a473b33ab9e029b2c2d7',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/174a3167e95c6098cdcc43f6c0e56fb9.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bad50598f6a7f7f278e89dc35cf81154',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/ff9da03739ad559843ddc40e6bd4595b.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '87d12c52b6f9122f1d63f1079193ea61',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/ab61129c89937b0296666f3cc851522a.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b8b7deac733eda93b3f1ac06fe4efa77',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/13d3883ce8b47d166b67c75d4e1442a7.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '49a84b8d7ba32708f4af16f207fb4f79',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/bdf344b7871b43da4ac80d01d016e037.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ce7e62f0db66e4ddff7bead128870a02',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/89816eb83fc3b55a9c6035cc55dcde3f.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'db9131382f40be5058249635b85c4e0a',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/78c6f6e22bbc395f6f49a9a719b9ec5e.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a3c7a1c9cb8c3207fe38b1f4befb48fd',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/3a80a59b53c968a44a70198ff0f7ba2f.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'df6718d137e55ecafb6477bbba50f3bf',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/10512abe2e4bd184d1fec2e33c5f9c7e.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e2b5153a2e8b20b0d6d5bc7b66adbfaa',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/22842d24f3e2a2e24544f91bd90a0c36.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '87c7a2aded19e5da08651b1fa4cacb20',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/48fb43a79889541db42dee2cd908b6a6.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '66d04c4b33beb06b4a68ee26a6dd2310',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/28c8fd2504b20d231db0769e17f868c7.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e252d04e757e24b2360ec43b389a90f1',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/cd972991eb63b15912ba9a0e8f06fefe.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8c96b0c4585997e7d58ff32b0c1e7e73',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/5b88e9fa1627575f070bfe04afa81fa2.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b635678267372131d4331389c4e37af',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/86e6bf4f234294a2626758587e8b0cec.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f13c2b49ef7fff9719535e7a9c78f0cd',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/2ec59f31d977e07d0500b75abe4f4592.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b86cf4ccf511acb3540f5341992f8a9',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/826e693c480de3cb7b071012ca17e753.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '084de4db2e407bf961bc07baddb8fb08',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/de6f9b29ae9458d2d1fbf93fecdee04b.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7e065ee85a6b2a252a24337aa7e8ed36',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/5a2e378777998eb08a878aa8dcf24dc7.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ea25d2f650d7f41251ddef0f6cbf6b9b',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/6bd4452f239c26d08115527fa91b4dd3.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6841ae0102607285b708a950e396bdf0',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/cea1d6ff99ad05d87a1a45701d443032.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '19c711f718b9cc310bf4c57ba36a45e5',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/c715cdbdc7f80bc51e46084d3cb9c8ec.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd137286f765bbb6525a864f8afc16bac',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/6b64a189a1eb343dd67b743899d42da5.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '389ae7732134b42b07ef96fb00e5876e',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/b95dc01a925d02585d5b27affff52c4b.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '83f0d88b35c5e19874f1cec5148d6e8b',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/b1f67a6df9b62e653e0693e1e6e007c2.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ae2e4438c28d9787f707f677bccf618',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/d98450a9c0bf29d131b41a59ee247f17.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '10ad0caa8449317c897654c64a04153c',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/de0c5c61243908b5681492ef53451cad.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c7ecdda545f3920f295ab2531209cf2d',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/cfaef4f39a7249afc2b96356940d3c89.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '15588e6ba075333c82d4f26efd46f698',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/683f18d7c23c8e1ea304f2e9641cfea1.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02270986741ff2a30c332a77ee3ebee8',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/1de79cfb6bdbb1d89454e07ad7227862.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b0e315ffbd0d072aae09ddd2c966bf70',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/2373cf42e444c5203052b6a1247888ed.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '545d144d57df26c95d30e405603c8ae6',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/9779f32ecbc92ae4275aaa8b3c6bf56a.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ebf6cd5dd58c0dea98f3b387890d9239',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/35eefc5a824f1afe8b26ee21eb56c273.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b64e3d96ad75f3ceabe6e3cb91bab37c',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/f7ed8d649834521f12ee3725b46d8b2b.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0d0dedf62449aa74d39df1a3e9971168',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/8a3c848d1300ce51bc500dca357ffa50.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ae0503d71044568b8d9948cc74ac2019',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/d77b31d2195ae8340e53da077759bc98.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '576ab67946297ce502db89c82bb7af3f',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/bbdbf4d82c3af222325275437aa59eb1.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f6539ba214aaeac55597bb00026b4cf',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e6f4d1b9367dcf3356de065204dfe6b6.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1d9a86b3abc9cedc0d382ef4f64fe4eb',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/5e3bc2ed78f0e68b1c46c8e3430a915b.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0dbe4ee7f8e9acbd0f8f509da1dd8390',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/34256900e2c793e2205a8998a95c46db.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '648fef91cf92ed3deae11cc548fa8760',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/d5fc8c940eba2da8af44e9db542a4d0c.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9198123be75daa6c93f062750fde1fdf',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/b7b19f871cb322be732f8670df98dca9.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eecaaf64f088c82d617ad8c016396905',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/38c3f489c24ddaa79b4f466a76062691.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dc5718c34fc9e8e62e857e89169003f3',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/ed82bd05349534f8d7747ebdec9f9fd9.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1a5cee4d05cdb9959df0d56ba76e922c',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/325be8fb6c0ff54ffba5d13c594c6a8f.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c456b171558e7771f5f81bbe2e8c643e',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/079017eb0863653d1a7d9df63f66dae7.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dfd2dfabff18eb7d7f53e21f78201aa5',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/94cbe50159c11fc7d55409d1f3e3a09c.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9a4131c3a42f15f528e3b3f353fe40b9',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/79677c204ff97064cfd38903d47d93a2.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f330cd5248b466fc9a082f7c4198dde',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/7353195b376030954cac040c3b8beaa2.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5eb5fbe46a0e32d1542161a9fa96a594',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/7147c033bf4c6b18ebb69272b8de7b32.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ca3406e18d61dc840a8095fc22ed098',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/6495ce2794b4770eb158455e9e0c95de.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01ea265fec58963716575a8c96f1eb24',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/11320fb739efe68bc2f1f45c99c7d628.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b7b990c822ce10f703f733f903833d4a',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/84ec6ae02cbb447dcfc47d73fca39a7f.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b6c958d69b9c6d9ced367c0516d67735',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/50a43f2c95cd6493ab2a24c3189ecc68.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '784b19c187633f5be25fa632b629f731',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/4d27c26dc12a6d0b0020a5e8f0d65b7b.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f452aeebad6a948717b27e37ccd95e54',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/d99feaad731d73b3a0e00e56f5f531e3.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b90e227e445e963cdd86f3734df2ad09',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/10c8ab2075e55db1c27b4ebdae062064.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '942122e1441f3145c3d48f7931538b6f',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/2475d36c4390ef477f17a24bdfeffdd4.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bfb5fb73e05fdd9a0ef7f0515d61e2db',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/cc9efad3bb33743fa02a4ca10f983e6d.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3047ac6257cb1bfd210f0d7abb22bedf',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/e8486a0d986ec2c33ee0bbbce87530f8.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '20833206b0bbb3ff213e053b38f95af5',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/8ea921269857edf55f4cd29cf0db1f93.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c4a84961447de03d00bdd47507df4e6c',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/22b6b8c7d64a7fa7b1a12850fe6d117b.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c5af4086259f25fd64962b22549a4f14',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/d06895eb77a05a78ef3a8abd08681860.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '03a184b29769092031dffe6592f1d933',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6a7a9db7f512a313ab55c161cfd662ff.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6e965a2fd6e9a2ea0b17bd968fe445bc',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/7fe4fcc3c35597b57886b60f4810e506.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ed4336276de8c81ca35abe9d335c7f2b',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/ed808846da9e3cda2b9375c6aefcf546.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '55ea4eed9bb4f3eaef4ab44979f1f55e',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/e1c22603ff2eb63c9a83b838fe6dbef7.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c38ce80067ccb1420ba1b571950197ca',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/60cbe99b24a401ceb64633ac97ad0f12.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3fab3d0d4aa196270589b12e0d03e613',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/03564f524094ab96100d8d29d2380084.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'caea33c97813b0507b0a31028a2a3071',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/a611017bbcad4b79b43d505c38621304.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8001c29157234f94c7b26d38426ec8ab',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/c1a289ae8c090de717d5f45ad7c396c6.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1a6d9075527f9558b5802a69a8af40f6',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/658de6c0ab0c6587d6b64213829da178.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '202b1f8c36b789784ddc5eabf700e4e9',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/e4b2a33fcbe85cf68a18620ec98440d9.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3e80c0a7a1bd504b7e6fe03370f16d17',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/ad0dccc0b7588fe18cfc63b735aa7154.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '70b2ba415faa49c85c7c89685b8e71aa',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/3c20a5f219e645d5235b636e82b66ce5.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7c282808a63e2824bc61c43d909b5194',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/d98ca3d6706062d1cafaf1ccc795aebb.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '652564e69f7f182c4114a26fed7e9417',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/3c267ff22d720b0d663f3eeae52df981.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cfcfd9eea6663cf771f06e0b9bed8578',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/d8a120de6ee70bab92072b5985951d1a.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '954ae2e1c3ac04c498d46cc100515dea',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/2b5bfdec0ad1f5fd28c46fba8b50d6d2.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cf5d6d2bf937bf27c48c58a8f32b94eb',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/d92021975e1823b3aa20529c60405426.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da6e9a41a21c7aee0b7d1f962cb320ae',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/1be2500c13781064174b2c0ab4463764.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9e683c44c7369e4c1dc7a370f4c7e495',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/b616c45fd40c7205b5ceaff5ce739d61.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb7d6ad7d866ae69bec857b4acb8796e',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/f6445908a419c106a57023fe3174c3bf.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11cf812de53e239f1d2a6f0fa832b866',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/0c3a913aff4cf232be531673c1aad5c7.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c70d0b068501eb2261a8a93219a1010e',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/9293f7ce72a89fe13787b1aceb51c107.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '66b6b709eb6b2cba816b810583d9823a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/d036a50f635a8f947c3bc40a10b38b45.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41f32c25d35bddfb6a81beaf36fac67b',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/7ba9dae7981e85e71a710c165b67941b.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2ac4489bdc29adf33dcea9d0cbc0abc6',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/98c4c6e3186f88a1fcaf07cd42f7833e.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '85d8241b5ca955abf1305bec8f93d653',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/94273939109bfd0376af38e14e27b4c0.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e10e14dde5007f9abf0278e9b4511b23',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/788e8fa8dffcc931a76fb95b18275c83.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4196e1cd97b7c318aca27e4a0f54f7f1',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/99808dc00cbafbdf4ee868e521916763.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '37c7bb3f035df3a3cd6897b716d82558',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/be71f1821f812d80f62a046509e207fd.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74c0014bae9da11d9426d46e2248f3e1',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/3ce3e894e881f0f9429e6df151d58913.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a18c1db66f9d04e31824c1dadbc04203',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/62ef08838d88688f81350b7b1c22558c.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09695a7a67f6a2cacd052d76b955b866',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/e2bb8e4c0555d8f984ef3c476d05cd76.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f2947f79769072cd7de9f2e8ed434788',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/83ac21668ead94ac8e9ebb3bc8539b8d.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28fdf378d2f37108eb6a3ef55434fa7c',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ab9f806b71da39a6346c9fecd7d29d7e.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25fc61499f378eb0b3e3fbe505569ca8',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/7cff57faa32e66ecacb99cace7ae34e8.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2191ea0246fc256822e095f1ff192490',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/770dbdff87099104a0c2a13c5a9e93c2.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e6da14c6a85053a9597586dd2c779427',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/cc1609dcc7d29e28d3f87926d89c7dbf.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '76dbacebe82490a6879255f9164e1553',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/5ae283e935280955f3e0c2cb3460a87b.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8cfe879c6aad454bd53fc561438d9eaa',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/69d5519b7991c37e1f6eacbbb6646180.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f7a9b8b45fcaa1ccf581c8c3e334b42f',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ac0d872ca4ef51b54699f7c18e95965c.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9a26bb2be2fef953441096cf93c8cf6d',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/9b5b62c838361086fba41bc1c9f820c2.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c47dbd2e5b3151b1c08a1a40d8f1c1d7',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/f6613cf94bafcf16f6c6240ec0fb80d9.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '03ffb9f79cecf96c12effd6f5030001d',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/66ecd255d4e3339d58f30682afe624a8.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '260cb1a62c7e93b3ff146a07f21d6884',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/882a434b65cd84d012bed12649af016b.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c868f0005d721bbf3f4d642137d8875a',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ec87e90b51645ab126d859ebe282645f.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6c14e5e1f44276c29482eb184d2cad6e',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/e791386aae89cde2a8acb4e339cccb49.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6bb39d9a3c5d374d2f54966590fefa36',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6e47fdf543707944b9e8066cd31a9cd4.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eb2896f6fa5955c894bd7e4f82dbe712',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/959c403e68da7839e72cb4be09479509.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '106f2776a4063af5df0721d34f9c2934',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/fdecbb8dcab53b072f5d201d187e9943.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd861aded7fb484cb9dab2be3cfbe5557',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/cd20f137e3a7aee5ed449bc913275aa2.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bd6a23c37eee6c49c18d6a1600cda973',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/0d3b4a51c319edc1a0e8157086544e0b.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a80c43d30a7bd63c9d3fbef7f035cf34',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/07972c3e8814bf7ab074eb78e41a0da8.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ac4e54b62225a1b2f4e211aa9fe0d368',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f2e658036b920bde184f9f52a589bc51.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5cd2f69abc4153d0e404ad7db7365185',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/d2d65613adae09511f475855258827ee.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e651221171791b33dbf21b0f1b386f4',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/5a420f23da1da3367d10a83afd9d2141.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '304e1919353a53376d9de9442c5238d1',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/96bc8e21e72d9ead4d324e978bb9774c.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9e3f86c24ab572fc5c808f59531299eb',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/dd98d8764fcf3f9ed9c1c693bb24cc95.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d4cb605210253d3df861115e8a5bf67',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/0a7237e6e5d53bb631b7439adf4a8262.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f081e5c89a6ce750ed22bdd7da1330a3',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/a3e6baa42ecc4a419c4705cc9e7c731c.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b3a76cfb48e1a9b1e5587e87e5bc3f73',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/6ea88bd4fac4128dbc21146bbd5a0938.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eff22b49db50aecf8dec2dd72678b040',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/b51f5888dec7e3789614600259adfb56.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a6b4eab5870eae99a84bf2912acf0859',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/cf04c1bcb5c945a16fdc35420d46e710.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c4c42d2e8bc8a663f37622c5b6cbd12',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/c5d3b01aa80aecd45f9ec758e6cec405.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a9be5db9208f5ed9fd589987e8404c83',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/a73e54cda93bded257bfe744581f5596.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '28b0673ac11b8d6e693eb4a0d7f8dcc1',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/53548fdaf1f5ef448f6de6f53616ec97.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20861a3a5f477cd39d10075fa0f3afa4',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/f4a570fb4c72c43077fb821f2b7a2826.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '96bc34b557b55570886578c867a02c94',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/a24f6ba037737641144dc62cfe7978e5.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd791616e6a0deb6b14a49f8f10b66461',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/811c75383879d1f4fdadbcfa93ad36a2.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ddf86d15c26719ef6d2f4f1a8ae035b9',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/04a5532210eb5218702b4c02e832da15.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c0dc3cf07d1f9abc02cccf1e4a8ff57a',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/ac1e58bfe40d86ba736e3221dc556e24.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ca383af1dbfd1e073ffba7886ac9858',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/0ecc6c156eae6dda3b1d60cb1912e3fd.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '70cfc6485b63af2ef74c9d5fd2256b03',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/016813ca9e29105557e1576005cbb741.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a7935c81af89a950a057f5794db2a3e',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/6549e898d57319600a6d3e345db724b3.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11903577a24c2feeff54de768927f95b',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/aba4cfd8c25fb2dc115b37f8d986ddfb.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3be88d60c067f98d707b50a3f70be35f',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/4d07157bc2d5616a0c4274b1f5652e11.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '936f1ab4d94f27e682e5594d7267cadd',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/3144406145f7e48878a9a3670b970df8.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa07ccad128c51e88799e54819aa8a7f',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/a31282ec9939192066d6ef3a4b54017b.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71b0d8fd8acb82f4b48b7c73d7ebf8c5',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/e034b470ca3e9a9f7850fe8bf4cd08b8.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '350b2e98a23c2c70fb8944030a5460c8',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/2229f59a9e8e89d14d676ba4bad564be.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e76c3ad762af8a033d5ab82fc4d0f287',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/be85babe5b00820cb992e35accd5b2b1.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '919fc7ba12471c6edaf793ebcfeba0a1',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/e0de016cc2ba6ec0282d351cffb0fa6d.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2b9f31b33ad5fb51fe00befd388bf0bd',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/2c84fa651fa68def5f5adae18d36a16e.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1c46f9908235c14ba6732ee285bba1f9',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/3cf31e159e1f98413458941c2a3d3f31.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d52123f4100bc8b2ce1e1f26de15e25',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/cd3258c13eebc1adf72d3d79597d253e.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbc2df153d093a039f980150c88532e8',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/ef76fcfca52c50aa22820a712a37acea.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e10a1061ac85d95c2d93bf7b8d954f36',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/d5123992f3015b12cc34aaae7773456b.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '954819ec70268dd13a51d90cb98edb32',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/cf4891b89d289fdbdf1d3a8315ee7c5e.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a710b25a88df7dd0cfb1cd06853cc01d',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/1797e0f41132b1f1d5ec2773fba8b8be.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ae78689edeaccc3da3c32735f5cba6f3',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/520af5523bffc2cd86203342093af5d3.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50bdadd2c59faefdc4324edb19e69a05',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/1463b03611a62e8cd19dd483445cc0c4.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ba432172fa06c50e70579680454a43e4',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/74b78556c8b03ba2b65d53d0fd22e663.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37ae76fa4a9f2eaf1751dd12ceef7267',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/95ede6be74071e3e8ea831b77fbafed0.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd5a00faa0deea79ca911e33799787773',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/827318399e563d1e8b89580640fdce21.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72d43fa9b284fc4e445ea8c0a0d72212',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/26eab24e74fc1501c63b5a0799b9da85.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ff8f39d1493a02ba336dfe30241eda1',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/419f9ac83e91be1f2445736c6167f815.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e610a5240c647c2852a993dfd2a4f7d',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/3c0ebd1d43a3d4a3bec33bb0e3a820d5.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6eff8f8dd8355a97bd2a486f6394a182',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/a63e548d55ffc83ec24da85c363f613b.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a8a654b56f5ff8c1a4d52f64ad4bed11',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/fdc29440598c8ac88efeca0f53028744.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '767af1bfd7d9a797d1fc36afdb5ea18b',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/5e2e21451e15425d3e5cd6dc26ee436f.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c1aee1cc4dfaa4d058a203d2a60f8b88',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/78412f1490ad6d899de11d9c835c63b2.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48f7edf622dc564f75c3bca850bed6d1',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/aea5c86a060f0654270e02bd9ba1d353.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e34a13dc5f98343d2ad862a137cbc7ea',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/eb4b740c67c366a2962e347ffd4cf4e4.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bec324571b4aefc9bf073987e69b219',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/cb1a4c02e01337f6301ecaf57b87fdb3.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e251cda20590291cd55bb64b3561656a',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/0378fc14d0df3c4617bf424e375f8021.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0c5298d9f4b822ba719d40ff080be2ee',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/031778c3ddb8406eeb5dfb3df945d388.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e5486d635c8ef2411eeec09414a5a9f7',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/305e8bb08ec11186e31640b074c16c35.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '53fda02680fdc456af918d180622c244',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/f5ab83df6f0ebe8c7d5e5639e5f5175b.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '07558dba8a6a2ffc5abfe44e8a4f2c7d',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/000708f7289e382590d1cabcb7da3e70.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6780ee7a74c7fb1e383d1af53208ff98',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/1b287bf4ec76f7205db67d229bfa2863.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '548a0f7679fd0fbfbd5e64b8da004560',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/0c9893211cfcf3fb3f6415c993baea73.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8b5730807e3bf2ba781f6824e780483f',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/0fc40756cc189f4490643908e1f35b46.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '19ba515ec151323144ab857dc3c608c0',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/4c95cc030ffcd69250578b0d7cf7eafe.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be3103796484c1fbe2bc52b30efb26a0',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/55fb181b269e4f96171aab5b8f7380a0.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '39c2fd8e961d0bccb76beffb0ea21f0b',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/f61034edeb6d329c87f921a315a8ef20.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22169a2534f68c2476d6fab739903bd3',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/f0aa75f950584402a8fbc4adee091368.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '90385ffea88665873fbbf08cdcae131e',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/655debfd07e11a90f4a75a58e70df451.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '792dac7946a500f09d223b011def2d7c',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/8575b1ce449ff24e5fc923cba3fe7108.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '610cba07d92320a637385203f2c0ee61',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/d1a96adfa6f571cfa4cb359846107332.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cdde78353dff71f1b507b25f3a99d8ce',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/59a90c73792441f617f02e4fb6285f44.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a9fe5fdcc29825f4e3cab36d01f1735',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/db718fcecf0873342b9d296bba92c74e.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fb59a21d6b278cadbfa5ff8e39cf783c',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/969b92ccee0a4d6451124cd4098860ff.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b181eb2b444de15cd2bbba56b30ac5b8',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/76e5e2f2af9d2bc4d23b3e5333a279f6.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd6bc34fe077ce4fa2ef61d981e359ab2',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/c1e213be16642c9ce8ddc25828d35233.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe75e23f9eedad4a4e7889847963c485',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/03a1e95749654eeb461b3d40046a6dc2.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a04ed25059ba215846a38d43282449b',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/1dc7741c6e7257940a656fc387595d9c.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62882491c1319ed0e54050e727359cb0',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/746cbdc3ee07d24b6b84d53af32f5147.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed842cbe26441a42314480b83bd1bdcc',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/a4fa404f7a7c2db29f40456653274998.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f3d39a0b2c673b201e834dbcc542b53',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/a79d6cedecec18424f98d264a7ddb3c5.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '95f909f4e9d39643c442008f7516d056',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/232afd6dcf4fa158c081b550f0e48016.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a51b2c5605c27b880e41a4fa03f39c4d',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/0da737d6e8d2132a06dcb2a2d5011248.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9e5790293d15f7526f265f1d5ba570c9',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/ed9817216e8f774d18e2a9708b90f112.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c40f0b469146cbf09d61227bec7c7ca3',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/2f66784884a77f775cfe3f30bce6dfa0.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be4b412a253536d64a7d9ce7d66ca2f6',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/520795f6d5247de69480d6b137228180.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8798dda66778bfe3bb5d09a1d09511d',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/c25a284c4ba52c1b5838e5a32056a277.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8812d83054e5cd65d8a3755b601ca7b8',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/831bf6b8d165c4a3fec6cb78462c36d0.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '126e85accef59f9249e8a4509068e9c7',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/613b90b7136795f5aff0a8abe6574401.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c75f8e26b7fcb06d3de87ca15e09e1d9',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/524ca0be596ad43b73e5d41613b31980.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '35257ace6425fa1b5bd204f83b472b54',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/da571f8a2e9411e7d9df2fb242e1229b.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '961f887a51a21519826f94eb0e18daac',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/2cba441f53a7332e51f53cf9781654b1.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bdc6db0e8f89c3ceb366c356c02f87bb',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/259de7543a301b740944721f3753cfe4.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '87a7619acdb379e762f06d0615a024f3',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/26c0f2b49afea5d445efe7c8fe48e391.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a98847ca69a2352060899374f3b5ba19',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/b434454ed864a97d84cb8486df87120d.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99f53fa036766a3dcf7bb810be5a2c59',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/5c4bba284b5aa633c078924f649a5fa3.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38fdb4c4ad528bae7da7dbe4adcdb897',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/cf129e11d90993da883bdbf8dad3eabb.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '84be955cdaf371c34c463cab826e23f1',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/aaef55e8635c7df88ae25a638c0f7480.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7dd348a7b6db04330b87c10c24c2d11b',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/b2eb96fd0f0a841d669c0b59ee7e8f9c.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '700df9c979864a072b7c36331888063a',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/4f7c39d68f093f2488c2d034e0a0a2d7.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '05d13dfda806abb6942a99e9134fff71',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/95ca2498f850899b6b23c14d1a9a4a06.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42cab747693ef6eb049e5fdf2cf8ef85',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/c82fce1394bb05887793b8fd6f7b84f4.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '69e1a0beffad69d046343ace5ae6e3fd',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/7a02ca5f5b1c9a7c30473694354c008c.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '716ce2f80da395f6ab36ca5955a0860d',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/8f000bd36f84fbf9505be2bd2ef00cfb.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cff21c07594bf132ecc265ce3a66a983',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/18cd39b1cba25081a5622ca11aa0d51f.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50d79e4966278c8ab575c6368bf5be18',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/82d7dc917f5247a87f9450aeeed918b5.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82d0b5d6ed34dbda60f03be803a7c544',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/43580b62ddab17c64f15e45b9a2aaead.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e500cf0f6c354be046e47529423bee00',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/bdf909a2975ff462dca397621a7dd926.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '114254b7f8e3f66c70fec6e111cafb7c',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/f466ebbc87298ec5b36599beb12b02b7.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '90ded8705b2255944bba167ae06fd5cb',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/43e79884ea6239498111f4bd133c61ff.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '921d5007e544af509d7e488cb29524c9',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/30209ba5681f77577362b34ceaddaabb.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd3824ca4227598ac3f4633ef824be570',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/899875027cd9c7ab456ff02c9c843a13.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9cc28b4035443e8413e00e0353fdcbc7',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/2017de1fa73e5885daefd917572f0fb8.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '05d5cb7a94ede2c9a6b49d44bfe64fba',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/824b07760c6fb269777a21fdb7caf560.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '30ac3fa8bbcce1b1608679b70a2a2e4a',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/8581761192fb7dbeaee192ffc6c2ab50.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5837580814471ca682367b87bba5e134',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/546d54d3126d73a84780e90abcf37c54.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57b569dbf148d34e4054a4f2e907d5c3',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/0a2721a634b177bf1d7cf0fa31d6968d.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '669c926c04c32e22172cbacf20a4904b',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/05263cc763f7e4a4720c6dfee3eabe45.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e34f2c5116f990d251d8ff0fa485bf66',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/db2899badf43be33a91cec4709d39ab6.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cb49f0ad4aeeef9044cce100060171eb',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/c279cae7aa028fc42bd1b299df721450.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1ccbefa711efa7306335c5bafc95c5f0',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/247a22f5e56a161e698322ea29f4b261.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2c6aaf840455012622439fa3c308f85',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/bde000446199cd9826eb02e7e5a201bf.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4763a46799e74ca7a45c81022ca6ea9',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/a3a0a19ee35d7300a3ef7def7fd5b978.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa0530caa3d1893e31602ec0b4441a53',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/8bcbf81d32c684a7c79c0085d58b02f9.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a41ae0aa27fef5012658b71fde327eba',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/1f7ab77a567e1fd506b77b6199a05a2f.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a691806605879af7d5a66c5a5629bfe2',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/2e4bcae8dece6e49fb512469096d11af.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '36c7bbf852ad86d04dd41d14b4966ae3',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/756c5e53737ff3d61d280a77b4de43a2.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a1c46454e06d3be9723938d0c068a00',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/c9aaf73509c67c1610ca351fa5f58b84.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f82bba4874debc8202207d72f82ff387',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/f281e8336bffa596b8d3f271a7ba7bc2.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3820d57e5f1c873cff34f883cdf255f5',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/9d18656cf40fa4e7e1e15c047cc76104.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c200c3cbc5d4dfa44945e093d0bf50c',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/c3a7e306190fe8ed58d5d60754348c26.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9490618f8e479bf7f98d2f1361431849',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/fd86057d277fb968f3b69d4301a9da51.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4c404336e107bc12e0251cf5999f8636',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/488778dac1362d6a518c1385f72d7df1.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73bcb6a3f9cdc8cd42aceef48391394d',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/622de10c0e81f7121210efbe6fd1b51a.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '036dd976371e9d5c3bd298bff08daa06',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/12350717a6f068a42f115fd9c969b983.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e810dee7ee44b0d3ad76745af96d4b6',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/d562a86f0437ab9618ed5aa67030aa6b.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f454ac70cab3e4b138ba8f51a7822cc',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/9026934c649f51ddfc0d89d046daa744.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe8b7f08fee99c7705e18d3eed6acbf8',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/bfc08acec45b86a73b3e6b1c09576aa2.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '78d875104efddc4926e08348b945d75d',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/189c2f6e7a799ed360faf7e1ca1f424a.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8de1efc607347e1705427dcdb9e6cb0f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/9306c2852c76c45e2f267150221e6e18.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4230c20faa3dae25bc9b13a077233e62',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/ac1af7a1731fd29ca2050436c637a50d.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1118b5a90b07fa1a3a6d7a1b30f18b71',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/00199fb8700b00c898506014a8a00d84.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2328592d932d7bfb4f7c21e0cd766950',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/e7be1109113cd35419c902a2eb3d0837.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ebbb140f83e078b1f6cfcb3bbecceb1',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/29272b680f4834764ed383a41fa08879.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9d8962ec288301b358cb7369675368b8',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/e8d136ac91c65954a02cce6d7b4a7615.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '147e3e622ba744e7f7213777939012ad',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/94ea14c97e8770cae7d42bedd5627b0d.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cc798927a1574c5bc4787dc6f4d1e052',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/f3c8935e78f5d3dd51dc53f4cddc194b.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bd365331b6c7efd0a518ef02b6e55967',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/7e9beab729594d449c6c79f934b8295c.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '86abe95ac75fcec070d2113e02f427e6',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d8cdcffd0d875ce0ff2c6839448bb8f8.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48506d825b8518bcc527ce5b0f12f487',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/b5949aa0a31c7083e808da1c751f0ecd.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c20e5331e00c774b7b0ab272fdd50855',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/a6d6c81d38292e85a762414b3ba56424.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9dd9e1900ff6e7a2b61a45cd10cf2a0b',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/1e5abd7c74da488c5b97ba99a92f0aa4.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e9914e4b911d371db7894a71fe3fbe32',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/2403f7bf9560ce72c3489579dcb97cae.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a665791c98b503ff11f37891d7b5a386',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/8f4225bbce52dbdfd9635b8484c9fd33.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5bc0de11296f225f8ab33151a37b358e',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/c0b83faf5c3c5bdb77f7084f569f3bfd.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '86eee89c27c3c31052ff683c3ad3919d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/f6ec98a8de3f31c369415ada4143c53a.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e52325d806d3baa27ffb9e99445f6a02',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/7096a7548b03bcf2a590621b189170fb.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21c8fce9b71fedba5122472548c9b24f',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/6251726e7df8b4059081ce7403276bf9.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '395ca1c3df2cc6ff7b97d7b337d302da',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/b7d7a685be9e92aa81255a77dc58d3ad.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '16e292f8289aaad6b92690ba84ad9cf3',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/c761c908e9b254137acf15f268a90c1d.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4455160a887cc00085816304ad02836b',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/fb7127a3018983368c00013db4ace403.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9b036dc9ccd3e3de4359b3161193a8e2',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/70455aad765e37e49c050d93e0c5524d.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac5db216c1a3ac9c6be003b7d4261207',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/5b1b97e21d4f281407dcf07e593907cb.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '802e52e913a9c4858e26a18920119a08',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/fa68aa96943c376ed5700ebfc99d7288.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3aef3b00d64288338410fa24d54e4d92',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/b7d8f1ebec3d3dcae24f3e713be4fb39.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2be256a92d4a7021799d2739e287c7e',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/45165b2b58ad4f9c7b2bf7a785742d64.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd678f8d771cdb4f19317927b99cc2078',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/0cb52245d96424f9f2d3d478ae1ace71.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c2d6d4e79875e89498b0961ccfd464c',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/344cb8b65de4e7b9ea51bf72033f202c.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '77d5938567b65c7c9cbefd23ca25186b',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/8dc178fd69619b0e9362a3ea66cd0894.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f7bf74e4b055838a89b72848d1b07e4b',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/b505507336ef5352b5a23ee5fa92f390.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5856405f27ae01f53fec3397335a8366',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/001d446ebad52e3fff648fcb0b779129.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '79ff69c8cb0b2396a1e48330d8f8d33d',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/7719bd466203544de6aef3dd6ea3f2d5.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f61f1c1d0752aba82cc33926609deb81',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/a71b9af26a9d1641705b732bc38fe996.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e5f604487579439ded9b4d5f8c4beaf6',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/6c659ec0b0e5be8ddba6f1e0a9a17863.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f34bad72e80d4b3b630cccf94027981d',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/6b2d39be18e3761ee804e2522b48858c.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b8ecbce82fd291ef5b138603c5026cf5',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/c05f7e5996a62c8eb0b8d10899f8cdd6.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8b23630b2769d89a5a7a85204285cb08',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/a120029b656a63be4461b510ac20e2d5.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cd26511e6b8ca8850b10a20ea22691d5',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/ee8bedfce2b711358b2f223da59237e4.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1f8691d79a6311ad1649cbacaa5b80ee',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/f1b013df08bdc55ba792e47392e51012.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '18c3537f35f489721b10a32c10e3e0ba',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/f7428afd4e208553a2283a1c56804da8.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '24c34122dd55cb9567dd68c676115564',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/8a1110a624f22efc0a86777f433939bf.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '072b9db65e1b551e35831cd4d0d1261a',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/d8fa8941f84da0c8c17ba0d38966a1e3.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9e2d5d83b5f8770882dd7e1875e669ee',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/a7c78cc003144400bf6fed34ab4084cb.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e2422305ec23e3e103d230bf2330d67a',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/abe09ba7d09add92bf4c2a638c5ef3cb.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '770632762d03f1b04d1616f4c77f0030',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/8fad2a8fd9e1b9c3ba8deb74db7f9e66.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '07713b9db4abdab03f666f2fc30dc260',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/d8141ea82bb03d842d0f18e91b285818.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2b3af9efba37fb4ef1a80515754f257d',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/19353af7ec3bc3e63e0c04305a4c8170.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f58ff2f55d37d0dff5ccf3de78f9ffd',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/0710e5fd3aaaa0528267eca548289c6d.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c94fb5ec99ec8836c0e1d463126bff1b',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/aa2aea5f5d5efd8a44e7c63e5df02bd4.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3c7eb9764ce586b17c30b87f2c3679e',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/8ea3d7deeb27ae88061ca68e61995890.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '80ae4fc5796592d8cb8ef70f6d3f5b8a',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/4a4289272b1d972f3526063e4f9f7a69.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '408f75fbb4edf8a6572f20bc03f62635',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/c87b9a3cb14ee3f20230255064b75ff5.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '900ce6e5e12e0fb7611c21ac07ff2668',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/350ece67a4d61cc6eb2d693fca928e9d.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e8bc43349056b38180e3dceedc8e9a14',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/ad5efb3d11082cf23cb8be9aee9f3090.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7e835c1a13e7dd0e5df25991d950fa8a',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/86a6d4918c78fd9837e437c3205dcceb.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b04e553580b79034d4ddf9f5843ea9cb',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/517b4acff305e7d931358668f95e7607.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e326f22a7ea7d15707d9b08909b232d6',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/11af19f9b9fc9aa28c6e9b389c5e7578.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bc796d44f2746471756b102fd055fc2c',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/49052bc0c426ea378f7be12dd0887431.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6f0667997550eb82bdeafe7711f7a13',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/87ad731027f86e862c5c3178ea9d5511.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ceb2597646638f0f340d27b1f636e19d',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/fbcfc0adbfe6fee8624b305c36e4c12e.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c1d3c47cd53a9c9bcffbcaefdba8a808',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/3cc085e618f4fdb1cb7f67dbd0db0076.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e23496921d369641601c89f0b8aa978',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/0f16b250ca64fe9ecf46793581f4994d.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f835f436bce2fca01a90fa861f495ed9',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/8e42c11e775d34971eb31f108e93d81c.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5bb1f34d1982a04cf0cdbcb52ac3cb8c',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/31b193526c037be75937525fcb46c66a.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a4eef63a4cae34c63a435b930fffa97',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/0d835709328bbf62c8c7a042d60d1d26.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '045358da2e311eb6080cd140adbe44b4',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/5a7e4c6aefaaa13e06ef4a56c6552805.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '666c64d25c4246f96d974f41034e5396',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/ec2d306aa0f949eb043d265d8c7ed775.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd242685dc78c5ab5e6741d781376e11a',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/f0dcf974aa50ffd89a32b5b018ab9020.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '565336f25c215a14f402aa40ec0b43ba',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/95efb7fee348115d5f4455405391ee85.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e0b4647107f0e0916ea92ddc349e4c0',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/542a663aa5455f47058c61e705ffda11.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8bda5a7fb0684310b30d392d8992fd72',
      'native_key' => 'upload_images',
      'filename' => 'MODX/Revolution/modSystemSetting/0bd8db30c47901fc94304a1df4a48d6e.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e0aaf0b440e803aafaa613e9b365811c',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/8c8f1b639a0173efe432f0b8d51bda64.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a00d53dfbd3edd87e2f7fbd99d28c840',
      'native_key' => 'upload_media',
      'filename' => 'MODX/Revolution/modSystemSetting/8edaca0305ee5caa5c3b7765450603ca.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f10671f86df319d985aa940b479ee82',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/a184ec514b0811a3cf1abe3f837b63e5.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '49eda5ff13094aedbcd4240a829c8eab',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/004e2b166a580e19a09e49183f535f73.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '452901e486aed7f167c0c945a80fee11',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/b9eb09086ea68e76abbdc506856e2a85.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '360bcfc12fc9a562067ab00dfefe54f0',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/90652d1c9609b7c1bea4a59e38765ef7.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be603684ee1f15e919fafa779ec1ed10',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/3a60e77aee13c13d2ccb4a505587bb3b.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6e6dd93ebb6c8b7f4d7ca4926cd52869',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/ee1c8e0a7c48fbfefb25cc179e3aefc6.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22c362fc5cb368e8b3deb3ea815f3456',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/c5f8b2327531e9d5223ae4bc4c577c45.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '087fd791c672d0c2f72ccdd91cec2163',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/47c5b6ff871e97877300874f27f145f1.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c1178c86fa0da81e8fc92deadcc1e38a',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/6aeb35da4f318f755311676a266e5e15.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2e35031c99a38b68cace7d39f92aaaab',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/2ce34a92e430ecd8b63f048ec37e4858.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9101178fe5e9774ab0d4f30b4d720c4d',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/d03d2a8ad8503431ba0983325f83ca5b.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc29efddf83c9e0083075697790513d7',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/be065fc0af8594a01199af0e029a5283.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e497128b44b951caa7cec848e3be918a',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/41eb6aa486c22f99dc719958d04b0698.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '97d643bcb117b3c8ec24d343b57f86d4',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/5ba2bf9adf4cf7570e479ec04d13ace2.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e21ea6be1399101599f7809a6d9c9784',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/1a966206035dfd6afd5fd6479057a060.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3d649b410dc290f185aacb0cfa56a77',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/7a2796726e1fad702bd27a224e443a58.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8e2aa5870c64074b08ddb0820e169cb4',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/c4c2a70e5589056badd7aa79ca078d01.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5e4a5650bc7702273a1ecbda65b7080',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/a4234cab1dd0a9a6b0b45a50d49681e5.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6181946dcba67f8fbd44dd49a1030f1d',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/7cadbd9806a40e33c9cd3e51a8ac5c08.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c8383f33d95517a7bd5dedc654407b27',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/d603e789921dad294e751e86c078abb1.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '985efa6031745146ced07ab00b6f0a67',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/d0b263cd86b7cad0deb8a4465d983d51.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '68ec940d77664f4fc8f05c01d667e4b4',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/6c7929b79d220b304b4baf96d02595ac.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '802a1d1bdf13fdb2c6b3a3ed22b778b8',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/5e27ee0fc532edc6ceb002beaf326463.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5a290b59596bdd22d8de6f802c080a08',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/1896f96d3c3ea198ff904196eb452b7b.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fbd38a33be27c8cc96264c5fdacda84d',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/520ce698f207583a61ef27da2c499e02.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1b399eecb369fcd47e660326d62af647',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/86a08fa025814e19cf36e174af2d9431.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc5e3ccee865a9de4c8a1a10ca1a7227',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/e44372d4f44609a1fd48656874859e9d.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '7623ddc191a0c4b1957ca8da5fc6425b',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/026e9f3cad2ed00943857a13619e1993.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '02e21cf419cf0ac420408120588439c5',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/86cf04b891f6a0a94590d0c8c5516925.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => '0a1d88b1a5977962c79535f0ee60693e',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/53ffbabf7b63d8ac2e54c3d4de36e4bf.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => '1a602604d3384607b04f0df8cd920fbe',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/fd056153968f571b6e3347e80276c2dd.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '437bb4a61c5a58e27dbdbbf8834fbe68',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/e667e3789c1a5f748b2a29b58b2abb8f.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '8e56dbbb2cb5d60c1e5aaf8776cf691a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/2e333d62201f5ffaf4b84f89674d1660.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '71534e5203a0cd03449d5015236a33d4',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/4679f5535e4d1c1c6da1bd2e88845bbf.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '4728c603d1f24b539c65b1192ba613bf',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/606d11909886a53e0d4bca5c92d43a2b.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'fc09561b59dbffed4d2d9e92d55abc18',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/93f82663edc7036f5bde9b1e4d89aa08.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'be84c2ca6323464578d94055de9249c1',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/dd2d4c9541053cef7ec7e1ae52e26708.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '815f1e84c300e8a5d5a5cbf0bf58809a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/6ce0a6f1942b8672b6830434414bf952.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'e11d652f9f8799ef9c38f52412c2885e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/4f3f1b8cef062f0ddc480c3b238e8ac8.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '83f8514653b675ffc3d2b387ed78d433',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/ce60b9294bf980dc682eb5e6ed9e6b8e.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '1ee354c0a68a14a500af829bf3f40b83',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/d7b9d87dfb85f6534976929a38c6d123.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '242bf1b720b4102c749149a2c7f18a6a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/3a68ea76ee0464b80108f0e27bfcd436.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '8b80e90b2ae5c8b45cdb12de8b947869',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/eff0a04b5d1d6ee96b3ef0ed4281e57e.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '29e12aa17f6c18dd810d6337b6cde3d2',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/1c89f893869a172001084c71e43db18c.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '085c1ce3590bbf52c89fe01d784e530e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/be8ba5980b3df58e8a48a705e5f8a933.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'c06da810996fe6fd1e7cd8222dfc968f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2bd55903ac07816c890cdca699d8bd3c.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'ac1afdd9dfe2f46d5f10783b66944890',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/912d766d742319af427f3b02357a4aae.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '970cdd1fab467a9a448ce40de5f2bcbd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/7286d2e46f48fbe93055df670e367172.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '33d2c85d32bfaed78612ac81bdccd9fd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/1ee78f4dd22480e120cdb686d1c6de46.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '81d85f7d158798ffd5afaf9ecca4944a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/c9885c0a92f06a739136f47069c73003.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'e4b656ba34f2140fdcf76c01ff377442',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/f98f354a877b888a526c3eea1451b1c1.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '24847d49387cccb03619eb3d40d45d0f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/c350871f202c0ab634bdb976010ddd0a.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'fc42ab48311ccf7de114f451606c557b',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/5d375481cf46982be9635f2be8bc4668.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '30e494a6979fae5f5452990c40d1d6bd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/720adf1da525f4ef579ea21217497f6d.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '6ab0dddbc6f46d6a4f4b23ed8731c7be',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/bbfaa38b676a2192e6a84c1c33497267.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6ee05a4c9edcda4a18cca2c9b4ba1fe9',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/388a4ed4abe4615348561694b18fe1e4.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '48628f315e5dd171e373febded1077ce',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/19030179451c6335a03c3d30734f1163.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '57f44eafaa0c3685cdf0545ad561f765',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/751971b9f30b791876713afe9472f75d.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '5491f594c85bdfe8a6abd81d7780cde0',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/9ae4ff182f049e29d7d769d957694a2e.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ec10295e8ccb12b51d7d8d9f8ad63f13',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/9ebc87b0b4b35d41045a0929adc77188.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '70fbca5eaf217069bcab101659605473',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/49f384774c86e0e228b6fb3d27c1d3b9.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '3b8fd81527079ef2e2b73819a933808b',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/b52c9905741d8b58a40b57c25410f4ed.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '5ce9125cbb89724252ad1956bd6d07ab',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/1295323b17c954f940cc381d1cbfd755.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '3a90c7717635c10f74b7d911cd5d15c4',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/22522aa07303492901c048c028c45408.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '18d3d78e1b1d610df1fa83f3e5bd0a97',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/47b4372619e5750ab940939f1d6af1ed.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '37c1b6dca605398288c1a704024d0d85',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/5d3addb3ce39a06fc3fbc67e3d4a79b7.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '0d415d89b191de859435ce3493e14714',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/be665371aef067650e2a5273920d73d0.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '17d62673cdd5fd88358452501d8d401a',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/0db004008f7d08ed554ef311db82a50e.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '56971f5a9b431b7d17930748395dcbb2',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/be03b4f815f7937f46d8cbb75c362300.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'af55531e1a0840e7fa2378d0fc55181c',
      'native_key' => 'af55531e1a0840e7fa2378d0fc55181c',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/aac1e2b63691ce24f61817b27905eba3.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c986e09c9af1840f6deff1e0a866a505',
      'native_key' => 'c986e09c9af1840f6deff1e0a866a505',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/a9498a707073668d24ea1284f7caed13.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'b75d8f2ba7fd48631a4953ee0497d80a',
      'native_key' => 'b75d8f2ba7fd48631a4953ee0497d80a',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/c8adb288e05710599b4fe09890657996.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '4a2c3409edd66b4b0c75a185f6febec9',
      'native_key' => '4a2c3409edd66b4b0c75a185f6febec9',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/2c1a94e0e6f0f5bc4b7e60896ab9a334.vehicle',
    ),
  ),
);